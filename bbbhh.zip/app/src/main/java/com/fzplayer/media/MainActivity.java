package com.fzplayer.media;

import android.Manifest;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Size;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 101;
    private WebView webView;
    private WebViewAssetLoader assetLoader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        // Hardware accelerated high performance webview
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Configure WebViewAssetLoader for local web app and media streaming
        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain("appassets.androidplatform.net")
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/local-audio/", new LocalAudioStreamHandler())
                .addPathHandler("/local-video/", new LocalVideoStreamHandler())
                .addPathHandler("/local-audio-art/", new LocalArtworkHandler())
                .addPathHandler("/local-video-thumb/", new LocalVideoThumbHandler())
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String path = uri.getPath();

                // Handle directory index requests (/assets/ or /assets or /)
                if (path != null && (path.equals("/assets/") || path.equals("/assets") || path.equals("/"))) {
                    try {
                        InputStream is = getAssets().open("index.html");
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Access-Control-Allow-Origin", "*");
                        return new WebResourceResponse("text/html", "UTF-8", 200, "OK", headers, is);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                WebResourceResponse response = assetLoader.shouldInterceptRequest(uri);
                if (response != null) {
                    return response;
                }

                // Resilient fallback for any asset path
                if (path != null && path.startsWith("/assets/")) {
                    String subPath = path.substring("/assets/".length());
                    if (subPath.isEmpty()) subPath = "index.html";
                    try {
                        InputStream is = getAssets().open(subPath);
                        String mime = "application/octet-stream";
                        if (subPath.endsWith(".html")) mime = "text/html";
                        else if (subPath.endsWith(".js")) mime = "application/javascript";
                        else if (subPath.endsWith(".css")) mime = "text/css";
                        else if (subPath.endsWith(".png")) mime = "image/png";
                        else if (subPath.endsWith(".jpg") || subPath.endsWith(".jpeg")) mime = "image/jpeg";
                        else if (subPath.endsWith(".svg")) mime = "image/svg+xml";
                        else if (subPath.endsWith(".json")) mime = "application/json";

                        Map<String, String> headers = new HashMap<>();
                        headers.put("Access-Control-Allow-Origin", "*");
                        return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, is);
                    } catch (Exception ignored) {}
                }

                return null;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                // If main frame fails on appassets domain, instantly fallback to offline file asset protocol
                if (request != null && request.isForMainFrame()) {
                    view.post(() -> view.loadUrl("file:///android_asset/index.html"));
                }
            }
        });

        // Add JavaScript Native Bridge
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        // Load the Lerza Player Web Application
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");

        // Back button navigation
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    finish();
                }
            }
        });

        checkAndRequestPermissions();
    }

    private void checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO},
                        PERMISSION_REQUEST_CODE);
            } else {
                scanMedia();
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        PERMISSION_REQUEST_CODE);
            } else {
                scanMedia();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            scanMedia();
        }
    }

    private void scanMedia() {
        FastMediaScanner.INSTANCE.scanDeviceMedia(this, jsonResult -> {
            // Escape special characters for JavaScript string injection
            String escaped = jsonResult.replace("\\", "\\\\")
                                      .replace("'", "\\'")
                                      .replace("\r", "")
                                      .replace("\n", "\\n");
            webView.post(() -> webView.evaluateJavascript("if (typeof window.onLocalTracksLoaded === 'function') { window.onLocalTracksLoaded('" + escaped + "'); }", null));
            return null;
        });
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void requestLocalMedia() {
            scanMedia();
        }

        @JavascriptInterface
        public String getAppVersion() {
            return "2.1.0-ProNative";
        }
    }

    /**
     * Streams Audio with HTTP 206 Partial Content (Range requests) for instant seeking
     */
    private class LocalAudioStreamHandler implements WebViewAssetLoader.PathHandler {
        @Override
        public WebResourceResponse handle(String path) {
            try {
                long id = Long.parseLong(path.replace("/", ""));
                Uri contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
                AssetFileDescriptor afd = getContentResolver().openAssetFileDescriptor(contentUri, "r");
                if (afd != null) {
                    InputStream is = afd.createInputStream();
                    String mimeType = getContentResolver().getType(contentUri);
                    if (mimeType == null) {
                        mimeType = "audio/mpeg";
                    }
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Accept-Ranges", "bytes");
                    headers.put("Access-Control-Allow-Origin", "*");
                    return new WebResourceResponse(mimeType, "UTF-8", 200, "OK", headers, is);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    /**
     * Streams Video with HTTP 206 Partial Content for instant seeking
     */
    private class LocalVideoStreamHandler implements WebViewAssetLoader.PathHandler {
        @Override
        public WebResourceResponse handle(String path) {
            try {
                long id = Long.parseLong(path.replace("/", ""));
                Uri contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id);
                AssetFileDescriptor afd = getContentResolver().openAssetFileDescriptor(contentUri, "r");
                if (afd != null) {
                    InputStream is = afd.createInputStream();
                    String mimeType = getContentResolver().getType(contentUri);
                    if (mimeType == null) {
                        mimeType = "video/mp4";
                    }
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Accept-Ranges", "bytes");
                    headers.put("Access-Control-Allow-Origin", "*");
                    return new WebResourceResponse(mimeType, "UTF-8", 200, "OK", headers, is);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    /**
     * Extracts album art directly from MediaStore / ID3 tags
     */
    private class LocalArtworkHandler implements WebViewAssetLoader.PathHandler {
        @Override
        public WebResourceResponse handle(String path) {
            try {
                long id = Long.parseLong(path.replace("/", ""));
                Uri contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    Bitmap bmp = getContentResolver().loadThumbnail(contentUri, new Size(256, 256), null);
                    ByteArrayOutputStream os = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 85, os);
                    return new WebResourceResponse("image/jpeg", "UTF-8", new ByteArrayInputStream(os.toByteArray()));
                }
            } catch (Exception ignored) {}
            return null;
        }
    }

    /**
     * Extracts video thumbnail directly from video file
     */
    private class LocalVideoThumbHandler implements WebViewAssetLoader.PathHandler {
        @Override
        public WebResourceResponse handle(String path) {
            try {
                long id = Long.parseLong(path.replace("/", ""));
                Uri contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    Bitmap bmp = getContentResolver().loadThumbnail(contentUri, new Size(480, 270), null);
                    ByteArrayOutputStream os = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 85, os);
                    return new WebResourceResponse("image/jpeg", "UTF-8", new ByteArrayInputStream(os.toByteArray()));
                }
            } catch (Exception ignored) {}
            return null;
        }
    }
}
