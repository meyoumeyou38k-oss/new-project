-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.fzplayer.media.** { *; }
-keep class androidx.media3.** { *; }
