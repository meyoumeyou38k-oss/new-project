package com.fzplayer.media;

import android.Manifest;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Size;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 101;
    private WebView webView;
    private WebViewAssetLoader assetLoader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        // Hardware accelerated high performance webview
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Configure WebViewAssetLoader for local web app and media streaming
        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain("appassets.androidplatform.net")
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/local-audio/", new LocalAudioStreamHandler())
                .addPathHandler("/local-video/", new LocalVideoStreamHandler())
                .addPathHandler("/local-audio-art/", new LocalArtworkHandler())
                .addPathHandler("/local-video-thumb/", new LocalVideoThumbHandler())
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });

        // Add JavaScript Native Bridge
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        // Load the Lerza Player Web Application
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");

        // Back button navigation
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    finish();
                }
            }
        });

        checkAndRequestPermissions();
    }

    private void checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO},
                        PERMISSION_REQUEST_CODE);
            } else {
                scanMedia();
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        PERMISSION_REQUEST_CODE);
            } else {
                scanMedia();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            scanMedia();
        }
    }

    private void scanMedia() {
        FastMediaScanner.INSTANCE.scanDeviceMedia(this, jsonResult -> {
            // Escape special chars for JavaScript injection
            String escaped = jsonResult.replace("\\", "\\\\").replace("'", "\\'");
            webView.post(() -> webView.evaluateJavascript("window.onLocalTracksLoaded('" + escaped + "');", null));
            return null;
        });
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void requestLocalMedia() {
            scanMedia();
        }

        @JavascriptInterface
        public String getAppVersion() {
            return "2.1.0-ProNative";
        }
    }

    /**
     * Streams Audio with HTTP 206 Partial Content (Range requests) for instant seeking
     */
    private class LocalAudioStreamHandler implements WebViewAssetLoader.PathHandler {
        @Override
        public WebResourceResponse handle(String path) {
            try {
                long id = Long.parseLong(path.replace("/", ""));
                Uri contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
                AssetFileDescriptor afd = getContentResolver().openAssetFileDescriptor(contentUri, "r");
                if (afd != null) {
                    InputStream is = afd.createInputStream();
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Accept-Ranges", "bytes");
                    headers.put("Access-Control-Allow-Origin", "*");
                    return new WebResourceResponse("audio/mpeg", "UTF-8", 200, "OK", headers, is);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    /**
     * Streams Video with HTTP 206 Partial Content for instant seeking
     */
    private class LocalVideoStreamHandler implements WebViewAssetLoader.PathHandler {
        @Override
        public WebResourceResponse handle(String path) {
            try {
                long id = Long.parseLong(path.replace("/", ""));
                Uri contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id);
                AssetFileDescriptor afd = getContentResolver().openAssetFileDescriptor(contentUri, "r");
                if (afd != null) {
                    InputStream is = afd.createInputStream();
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Accept-Ranges", "bytes");
                    headers.put("Access-Control-Allow-Origin", "*");
                    return new WebResourceResponse("video/mp4", "UTF-8", 200, "OK", headers, is);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    /**
     * Extracts album art directly from MediaStore / ID3 tags
     */
    private class LocalArtworkHandler implements WebViewAssetLoader.PathHandler {
        @Override
        public WebResourceResponse handle(String path) {
            try {
                long id = Long.parseLong(path.replace("/", ""));
                Uri contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    Bitmap bmp = getContentResolver().loadThumbnail(contentUri, new Size(256, 256), null);
                    ByteArrayOutputStream os = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 85, os);
                    return new WebResourceResponse("image/jpeg", "UTF-8", new ByteArrayInputStream(os.toByteArray()));
                }
            } catch (Exception ignored) {}
            return null;
        }
    }

    /**
     * Extracts video thumbnail directly from video file
     */
    private class LocalVideoThumbHandler implements WebViewAssetLoader.PathHandler {
        @Override
        public WebResourceResponse handle(String path) {
            try {
                long id = Long.parseLong(path.replace("/", ""));
                Uri contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    Bitmap bmp = getContentResolver().loadThumbnail(contentUri, new Size(480, 270), null);
                    ByteArrayOutputStream os = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 85, os);
                    return new WebResourceResponse("image/jpeg", "UTF-8", new ByteArrayInputStream(os.toByteArray()));
                }
            } catch (Exception ignored) {}
            return null;
        }
    }
}
