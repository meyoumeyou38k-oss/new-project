package com.fzplayer.media

import android.app.Application

class LerzaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        // Pre-warm FastMediaScanner cache in background thread
        FastMediaScanner.initialize(this)
        // Pre-warm ExoPlayer hardware audio engine
        ExoMediaEngine.initialize(this)
    }

    companion object {
        lateinit var instance: LerzaApplication
            private set
    }
}
